# NextFly iOS v2.0.6 — "What's New" H5

Static page for the in-app WebView. No build step, no server-side code, no
runtime network calls: nothing is fetched from any other host, so it renders
fully offline once cached.

## What to upload

```
index.html
assets/           16 images
```

Upload both, keeping `assets/` as a sibling of `index.html`. Every path in the
page is relative, so it works at any URL depth — `/release-notes/ios/`,
`/h5/whatsnew/`, or a bucket root, no configuration needed.

`index.standalone.html` is an alternative: one file with every image inlined
as a data URI and no `assets/` folder. Use it only if the backend accepts a
single file and nothing else — it is larger and blocks first paint behind the
whole payload, where the split version parses and paints immediately while
images stream in parallel. Do not upload both.

## Server configuration

One thing to check: **`.webp` must be served as `image/webp`.** Most stacks do
this already; some older nginx builds ship a `mime.types` that predates WebP.
If it is served as `application/octet-stream` the screenshots silently fail to
render, because a `<picture>` whose `<source>` fails does *not* fall back to
its `<img>`. Verify with:

```
curl -sI https://<host>/<path>/assets/shot-1.webp | grep -i content-type
```

Suggested caching: the files under `assets/` are content-stable, so they take a
long `max-age`. Give `index.html` a short one (or `no-cache`) so copy fixes go
out without waiting for a cache to expire.

## URL parameters

All optional. `https://<host>/<path>/?lang=ja&v=2.0.6`

| Param | Behaviour |
|---|---|
| `lang` / `locale` / `hl` | BCP-47 tag, checked in that order. Falls back to `navigator.language`, then `en`. |
| `v` | Version shown in the heading. Defaults to `2.0.6`. |
| `vw` | The word before the version. Defaults to `Version`. |
| `theme` | `light` / `dark`. See below — normally omit it. |

Supported languages: `en fr de it es ja ko zh-TW id hi ru`. Any `zh*` resolves
to `zh-TW`; anything unmatched falls back to `en`. Inside a WKWebView
`navigator.language` already follows the app locale, so `lang` only needs
passing if the app has its own language setting that can diverge from it.

## Dark mode

The page follows the OS through `prefers-color-scheme`. No JavaScript is
involved and **no parameter is required.**

The one thing to verify on the client side: WKWebView answers that query from
the trait collection of the view hosting it, not from iOS Settings. Since the
app has its own Appearance control, the two can disagree unless the app's
choice is applied to the web view or an ancestor:

```swift
webView.overrideUserInterfaceStyle = .dark   // or .light, or .unspecified
```

Apps that set this on the window already cover the WebView by inheritance. To
check: set the phone to Light, the app to Dark, and open the page — it should
render dark. If it renders light, either apply the override or pass
`?theme=dark`, which the page honours and which takes precedence over the
media query.

On Android WebView the equivalent is
`WebSettingsCompat.setAlgorithmicDarkeningAllowed(settings, true)`.

## Verified before packaging

- 214 computed-style assertions against the design handoff, across light and
  dark and three widths
- 66 layout combinations: 11 locales x 3 viewports x 2 colour schemes, checking
  horizontal overflow, clipped glyphs, unresolved copy, broken images and
  correct locale resolution

Not covered, and still worth a pass on a real device: safe-area insets,
scroll rubber-banding, and the Appearance check described above.
